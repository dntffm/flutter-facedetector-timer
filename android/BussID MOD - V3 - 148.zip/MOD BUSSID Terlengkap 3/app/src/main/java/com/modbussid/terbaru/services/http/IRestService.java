package com.modbussid.terbaru.services.http;

public interface IRestService<T> {
    void onStart(int code);
    void onFinish(int code, ResultObject<T> value);
}