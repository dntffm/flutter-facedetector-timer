package com.modbussid.terbaru.helpers;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;

import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class ViewHelper {
    public static void slideUp(View view) {
        view.setVisibility(View.VISIBLE);
        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                view.getHeight(),  // fromYDelta
                0);                // toYDelta
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
    }

    public static void slideDown(View view) {
        TranslateAnimation animate = new TranslateAnimation(
                0,                 // fromXDelta
                0,                 // toXDelta
                0,                 // fromYDelta
                view.getHeight()); // toYDelta
        animate.setDuration(500);
        animate.setFillAfter(true);
        view.startAnimation(animate);
    }

    public static void showSnackbarWarning(Context context, String msg, View view) {
        try {
            InputMethodManager inputMethodManager =
                    (InputMethodManager) context.getSystemService(
                            Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(
                    ((Activity)context).getCurrentFocus().getWindowToken(), 0);
        }catch (Exception ex) {
        }

        if(view == null) {
            view = ((Activity)context).getWindow().getDecorView().getRootView();
        }

        Snackbar snackbar = Snackbar.make(context, view, msg, Snackbar.LENGTH_LONG);
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams)
                snackbar.getView().getLayoutParams();
        Resources resources = context.getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android");
        params.setMargins(0, 0, 0, resources.getDimensionPixelSize(resourceId));
        snackbar.getView().setLayoutParams(params);
        snackbar.show();
    }

    public static void showSnackbarWarningShort(Context context, String msg, View view) {
//        Snackbar.with(context, view)
//                .type(Type.UPDATE)
//                .message(msg)
//                .duration(Duration.SHORT)
//                .fillParent(true)
//                .textAlign(Align.CENTER)
//                .show();
    }

    public boolean isInternetWorking() {
        boolean success = false;
        try {
            URL url = new URL("https://google.com");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setConnectTimeout(10000);
            connection.connect();
            success = connection.getResponseCode() == 200;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return success;
    }
}
