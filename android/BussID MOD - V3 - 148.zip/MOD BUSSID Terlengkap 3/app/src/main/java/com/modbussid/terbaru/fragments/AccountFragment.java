package com.modbussid.terbaru.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.modbussid.terbaru.R;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.common.collect.ImmutableList;
import com.modbussid.terbaru.adapters.MenuAdapter;
import com.modbussid.terbaru.models.Menu;
import com.modbussid.terbaru.services.http.IRestService;
import com.modbussid.terbaru.services.http.RestPostService;
import com.modbussid.terbaru.services.http.ResultObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AccountFragment extends BaseFragment {
    View view;
    TextView tvName, tvMemberStatus;
    CircleImageView ivImage;
    ImageView ivProBadge;

    View vwSubscribe;
    Button btnLogin;

    BillingClient billingClient;

    RestPostService restPostService;

    MenuAdapter menuAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_account, null);
        ivProBadge = view.findViewById(R.id.ivProBadge);
        tvName = view.findViewById(R.id.tvName);
        ivImage = view.findViewById(R.id.ivImage);
        tvMemberStatus = view.findViewById(R.id.tvMemberStatus);
        vwSubscribe = view.findViewById(R.id.vwSubscribe);
        btnLogin = view.findViewById(R.id.btnLogin);

        restPostService = new RestPostService(getContext(), new IRestService() {
            @Override
            public void onStart(int code) {
                if (code == 2) {
                    tvMemberStatus.setVisibility(View.GONE);
                    ivProBadge.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFinish(int code, ResultObject value) {
                if (value.isStatus()) {
                    if (code == 1) {
                        ConsumeParams consumeParams = ConsumeParams.newBuilder()
                                .setPurchaseToken((String) value.getValue())
                                .build();
                        ConsumeResponseListener listener = (billingResult, purchaseToken) -> {
                            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                            }
                        };

                        billingClient.consumeAsync(consumeParams, listener);
                    } else if (code == 2) {
                        JSONObject jsonObject = (JSONObject) value.getValue();
                        try {
                            String expiredAt = jsonObject.getString("expired_at");

                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                            SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
                            tvMemberStatus.setVisibility(View.VISIBLE);
                            ivProBadge.setVisibility(View.VISIBLE);
                            vwSubscribe.setVisibility(View.GONE);
                            tvMemberStatus.setText(String.format("VIP User until %s", sdf1.format(sdf.parse(expiredAt))));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                } else {
                    if (code == 2) {
                        tvMemberStatus.setText("Free User");
                    }
                }
            }
        });
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(getContext(), gso);

        RecyclerView rvList = view.findViewById(R.id.rvList);
        rvList.setLayoutManager(new LinearLayoutManager(getContext()));
        menuAdapter = new MenuAdapter((mode, data) -> {
            Intent intent = null;
            switch (data.getTitle()) {
//                case "Login":
//                    intent = mGoogleSignInClient.getSignInIntent();
//                    break;
//                case "Berlangganan 1 Bulan (Rp 5.000)":
//                    buyProduct("montly_subscribtion");
//                    break;
//                case "Berlangganan 1 Tahun (Rp 50.000)":
//                    buyProduct("yearly_subscribtion");
//                    break;
                case "Official Website":
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("https://modbussid.co.id"));
                    break;
                case "Aplikasi Kami yang lainnya":
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("https://modbussid.co.id/aplikasi-kami-yang-lainnya/"));
                    break;
                case "Facebook":
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("https://m.facebook.com/modbussimulatorid"));
                    break;
                case "Group Facebook":
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("https://m.facebook.com/groups/904409856641128/"));
                    break;
                case "Instagram":
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse("https://www.instagram.com/modbussid.indonesia/"));
                    break;
                case "Logout":
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case DialogInterface.BUTTON_POSITIVE:
                                    mGoogleSignInClient.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            setMenu(null);
                                        }
                                    });
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };
                    AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                    builder.setMessage(getString(R.string.logout_title))
                            .setPositiveButton(getString(R.string.logout), dialogClickListener)
                            .setNegativeButton(getString(R.string.cancel), dialogClickListener).show();
                    break;
            }

            try {
                if (intent != null) {
                    if (data.getTitle().equals("Login")) {
                        startActivityForResult(intent, 1);
                    } else {
                        startActivity(intent);
                    }
                }
            } catch (Exception e) {
                Toast.makeText(requireContext(), "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
            }

        });
        rvList.setAdapter(menuAdapter);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getActivity());
        setMenu(account);

        billingClient = BillingClient.newBuilder(getContext())
                .setListener(new PurchasesUpdatedListener() {
                    @Override
                    public void onPurchasesUpdated(@NonNull BillingResult billingResult, @Nullable List<Purchase> purchases) {
                        if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK
                                && purchases != null) {
                            for (Purchase purchase : purchases) {
                                handlePurchase(purchase);
                            }
                        } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
                            // Handle an error caused by a user cancelling the purchase flow.
                        } else {
                            // Handle any other error codes.
                        }
                    }
                })
                .enablePendingPurchases()
                .build();

        view.findViewById(R.id.btnSubscribeWeekly).setOnClickListener(view1 -> {
            buyProduct("weekly_subscription");
        });
        view.findViewById(R.id.btnSubscribeMonthly).setOnClickListener(view1 -> {
            buyProduct("montly_subscribtion");
        });
//        view.findViewById(R.id.btnLogOut).setOnClickListener(view1 -> {
//            mGoogleSignInClient.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
//                @Override
//                public void onComplete(@NonNull Task<Void> task) {
//                    view.findViewById(R.id.signInGoogle).setVisibility(View.VISIBLE);
//                    view.findViewById(R.id.tvIntro).setVisibility(View.VISIBLE);
//                    view.findViewById(R.id.btnLogOut).setVisibility(View.GONE);
//                    view.findViewById(R.id.vwSubscribe).setVisibility(View.GONE);
//
//                    tvName.setText("Hi, Guest!");
//                    ivImage.setImageResource(R.drawable.logo);
//                }
//            });
//        });

        btnLogin.setOnClickListener(view1 -> {
            Intent intent = mGoogleSignInClient.getSignInIntent();
            startActivityForResult(intent, 1);
        });

        return view;
    }

    private void setMenu(GoogleSignInAccount account) {
        menuAdapter.data.clear();
        if (account != null) {
            displayUser(account);
//            menuAdapter.data.add(new Menu("Berlangganan", 0));
//            menuAdapter.data.add(new Menu("Berlangganan 1 Bulan (Rp 5.000)", R.drawable.logo));
//            menuAdapter.data.add(new Menu("Berlangganan 1 Tahun (Rp 50.000)", R.drawable.logo));
            btnLogin.setVisibility(View.GONE);
            vwSubscribe.setVisibility(View.VISIBLE);
            restPostService.UserStatus(2, account.getEmail());
        } else {
            tvName.setText("Hi, Guest!");
            ivImage.setImageResource(R.drawable.logo);
            ivProBadge.setVisibility(View.GONE);
            btnLogin.setVisibility(View.VISIBLE);
            vwSubscribe.setVisibility(View.GONE);
//            menuAdapter.data.add(new Menu("Login untuk Upgrade Akun", 0));
        }
        menuAdapter.data.add(new Menu("Menu", 0));
        menuAdapter.data.add(new Menu("Official Website", R.drawable.logo));
        menuAdapter.data.add(new Menu("Aplikasi Kami yang lainnya", R.drawable.logo));
        menuAdapter.data.add(new Menu("Sosial Media", 0));
        menuAdapter.data.add(new Menu("Instagram", R.drawable.logo));
        menuAdapter.data.add(new Menu("Facebook", R.drawable.logo));
        menuAdapter.data.add(new Menu("Group Facebook", R.drawable.logo));
        if (account != null) {
            menuAdapter.data.add(new Menu("Logout", R.drawable.logo));
        }
        menuAdapter.notifyDataSetChanged();
    }

    private void buyProduct(String productID) {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    QueryProductDetailsParams queryProductDetailsParams =
                            QueryProductDetailsParams.newBuilder()
                                    .setProductList(
                                            ImmutableList.of(
                                                    QueryProductDetailsParams.Product.newBuilder()
                                                            .setProductId(productID)
                                                            .setProductType(BillingClient.ProductType.INAPP)
                                                            .build()))
                                    .build();

                    billingClient.queryProductDetailsAsync(
                            queryProductDetailsParams,
                            new ProductDetailsResponseListener() {
                                public void onProductDetailsResponse(BillingResult billingResult,
                                                                     List<ProductDetails> productDetailsList) {
                                    ImmutableList<BillingFlowParams.ProductDetailsParams> productDetailsParamsList =
                                            ImmutableList.of(
                                                    BillingFlowParams.ProductDetailsParams.newBuilder()
                                                            .setProductDetails(productDetailsList.get(0))
                                                            .build()
                                            );

                                    BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                                            .setProductDetailsParamsList(productDetailsParamsList)
                                            .build();

                                    billingClient.launchBillingFlow(getActivity(), billingFlowParams);
                                }
                            }
                    );
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.
            }
        });
    }

    void handlePurchase(Purchase purchase) {
        if (getContext() != null) {
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getContext());
            if (account != null) {
                restPostService.Purchase(1, account.getEmail(), account.getDisplayName(), purchase.getOriginalJson());
            }
        }
    }

    private void displayUser(GoogleSignInAccount account) {
        tvName.setText(String.format("Hi %s", account.getDisplayName()));
        Glide.with(getContext())
                .load(account.getPhotoUrl())
                .addListener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, @Nullable Object model, @NonNull Target<Drawable> target, boolean isFirstResource) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            ivImage.setImageResource(R.drawable.logo);
                        });
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(@NonNull Drawable resource, @NonNull Object model, Target<Drawable> target, @NonNull DataSource dataSource, boolean isFirstResource) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            ivImage.setImageDrawable(resource);
                        });
                        return false;
                    }
                }).submit();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == 1) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            setMenu(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("GOOGLE", "signInResult:failed code=" + e.getStatusCode());
//            updateUI(null);
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    billingClient.queryPurchasesAsync(
                            QueryPurchasesParams.newBuilder()
                                    .setProductType(BillingClient.ProductType.INAPP)
                                    .build(),
                            (billingResult1, purchases) -> {
                                if (billingResult1.getResponseCode() == BillingClient.BillingResponseCode.OK
                                        && purchases != null) {
                                    for (Purchase purchase : purchases) {
                                        handlePurchase(purchase);
                                    }
                                } else if (billingResult1.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
                                    // Handle an error caused by a user cancelling the purchase flow.
                                } else {
                                    // Handle any other error codes.
                                }
                            });
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.
            }
        });
    }
}
