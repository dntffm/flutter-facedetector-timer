package com.modbussid.terbaru.models;

public class Content {
    // 0 = POST, 1 = ADS
    public static int POST_TYPE = 0;
    public static int ADS_TYPE = 1;
    private int type = 0;
    private Post post1, post2;

    public Content(int type, Post post1, Post post2) {
        this.type = type;
        this.post1 = post1;
        this.post2 = post2;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Post getPost1() {
        return post1;
    }

    public void setPost1(Post post1) {
        this.post1 = post1;
    }

    public Post getPost2() {
        return post2;
    }

    public void setPost2(Post post2) {
        this.post2 = post2;
    }
}
