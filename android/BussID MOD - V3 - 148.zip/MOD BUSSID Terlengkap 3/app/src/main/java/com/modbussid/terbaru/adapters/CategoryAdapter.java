
package com.modbussid.terbaru.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.modbussid.terbaru.R;
import com.modbussid.terbaru.models.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {
    public List<Category> data = new ArrayList<>();
    private IAdaperListener<Category> adapterListener;
    Context context;
    public int selectedIndex = -1;

    public CategoryAdapter(IAdaperListener<Category> adapterListener) {
        this.adapterListener = adapterListener;
    }

    @Override
    public int getItemViewType(int position) {
        if(data.isEmpty()) {
            return 0;
        }

        return selectedIndex == position ? 1 : 2;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case 1:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_category_selected, parent, false);
                break;
            default:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_category, parent, false);

        }
        context = view.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if(holder.getItemViewType() < 1) {
            return;
        }

        holder.loadData(data.get(position));
        holder.mView.setOnClickListener(view -> {
            int oldIndex = selectedIndex;
            selectedIndex = position;
            notifyItemChanged(oldIndex);
            notifyItemChanged(selectedIndex);
            adapterListener.onSelect(1, data.get(position));
        });
    }

    @Override
    public int getItemCount() {
        return data.isEmpty() ? 1 : data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public ImageView ivImage;
        public TextView tvName;
        public Category mItem;

        public void loadData(Category mItem) {
            this.mItem = mItem;
            tvName.setText(mItem.getName());
        }

        public ViewHolder(View view) {
            super(view);
            mView = view;
            ivImage = view.findViewById(R.id.ivImage);
            tvName = view.findViewById(R.id.tvName);
        }
    }
}
