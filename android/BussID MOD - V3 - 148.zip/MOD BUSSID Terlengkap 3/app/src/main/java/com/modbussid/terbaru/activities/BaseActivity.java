package com.modbussid.terbaru.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.modbussid.terbaru.R;

public class BaseActivity extends AppCompatActivity {

    ImageView ivBack;
    TextView tvPageTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void setupToollbar() {
        ivBack = findViewById(R.id.ivBack);
        tvPageTitle = findViewById(R.id.tvPageTitle);

        ivBack.setOnClickListener(view -> {
            finish();
        });
    }

    public void setUpToolbarPostRoot()
    {
        ivBack = findViewById(R.id.ivBack);
        tvPageTitle = findViewById(R.id.tvPageTitle);

        ivBack.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);// New activity
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }
    public void setPageTitle(String title) {
        tvPageTitle.setText(title);
    }
}