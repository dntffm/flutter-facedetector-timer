package com.modbussid.terbaru.dialogs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.modbussid.terbaru.R;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class ReviewDialog extends BottomSheetDialogFragment {
    ReviewDialogCallback reviewDialogCallback;
    float rate = 0;

    public ReviewDialog(ReviewDialogCallback reviewDialogCallback) {
        this.reviewDialogCallback = reviewDialogCallback;
    }

    RatingBar ratingBar;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_review, container, false);
        ratingBar = view.findViewById(R.id.ratingBar);
        ratingBar.setRating(rate);
        view.findViewById(R.id.btnReview).setOnClickListener(view1 -> {
            reviewDialogCallback.onReview(ratingBar.getRating());
            dismiss();
        });
        return view;
    }

    public void setRate(Double userRate) {
        rate = userRate.floatValue();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(BottomSheetDialogFragment.STYLE_NORMAL, R.style.CustomBottomSheetDialogTheme);
    }

    public interface ReviewDialogCallback {
        void onReview(float rate);
    }
}
