package com.modbussid.terbaru.models;

import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Banner {
    private int id;
    private String image;

    public int getId() {
        return id;
    }

    public String getImage() {
        return image;
    }

    public static Banner fromJSON(JSONObject jsonObject) {
        return new GsonBuilder().create().fromJson(jsonObject.toString(), Banner.class);
    }
    public static List<Banner> fromJSON(JSONArray jsonArray) throws JSONException {
        List<Banner> result = new ArrayList<>();
        for(int i = 0; i < jsonArray.length(); i++) {
            result.add(fromJSON(jsonArray.getJSONObject(i)));
        }

        return result;
    }
}
