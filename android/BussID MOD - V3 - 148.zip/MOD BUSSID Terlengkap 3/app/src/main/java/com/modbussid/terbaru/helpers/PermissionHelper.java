package com.modbussid.terbaru.helpers;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class PermissionHelper {
    public static boolean CheckIfAlreadyhavePermission(Activity activity, String[] perms, int requestCode) {
        int MyVersion = Build.VERSION.SDK_INT;
        if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {

            List<String> newPerms = new ArrayList<String>();

            for(String perm : perms) {
                if(ContextCompat.checkSelfPermission(activity, perm) != PackageManager.PERMISSION_GRANTED) {
                    newPerms.add(perm);
                };
            }

            if(newPerms.size() > 0) {
                ActivityCompat.requestPermissions(activity, newPerms.toArray(new String[newPerms.size()]), requestCode);
                return false;
            }
        }

        return true;
    }

    public static boolean CheckIfAlreadyhavePermission(Fragment fragment, String[] perms, int requestCode) {
        int MyVersion = Build.VERSION.SDK_INT;
        if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {

            List<String> newPerms = new ArrayList<String>();

            for(String perm : perms) {
                if(ContextCompat.checkSelfPermission(fragment.getContext(), perm) != PackageManager.PERMISSION_GRANTED) {
                    newPerms.add(perm);
                };
            }

            if(newPerms.size() > 0) {
                fragment.requestPermissions(newPerms.toArray(new String[newPerms.size()]), requestCode);
                return false;
            }
        }

        return true;
    }

}
