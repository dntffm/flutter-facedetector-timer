package com.modbussid.terbaru.services.http;

import android.content.Context;
import android.util.Log;

import com.afollestad.materialdialogs.MaterialDialog;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.modbussid.terbaru.helpers.DataHelper;
import com.modbussid.terbaru.helpers.ViewHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.IllegalCharsetNameException;
import java.util.HashMap;
import java.util.Map;

public class RestService {
    public static String BASE_URL = "https://adminpanel3.modbussid.co.id/";
    public static String BASE_URL_API = BASE_URL + "api/";
    Context context;
    boolean isShowLoading = false;
    boolean isShowError = false;
    String loadingText = "";
    int statusCode = 0;
    public boolean isRedirectToLogin = true;

    MaterialDialog loadingDialog;

    public RestService(Context context){
        this.context = context;
    }

    String encodeValue(String value) {
        try {
            return URLEncoder.encode(value, "utf-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return value;
        } catch (IllegalCharsetNameException e) {
            e.printStackTrace();
            return value;
        }
    }

    String getBaseURL() {
//        String savedServer = DataHelper.String(context, "SERVER");
//        if(savedServer.equals("")) {
//            return BASE_URL_API;
//        } else {
//            return savedServer + "/api";
//        }
        return BASE_URL_API;
    }

    public void doGet(final int code, String path, HashMap<String, String> params) {
        if(DataHelper.Boolean(context, "IS_LOGIN")) {
            params.put("user_id", DataHelper.String(context, "USER_ID"));
        }

        String url = getBaseURL() + path;
        url = url + "?";
        for(String key : params.keySet()) {
            url = url + key + "=" + encodeValue(params.get(key)) + "&";
        }
        Log.i("VOLLEY", "URL : " + url);
        Log.i("VOLLEY", "PARAM : " + params);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i("VOLLEY", response);
                try {
                    RestService.this.onSuccess(code, new JSONObject(response));
                } catch (JSONException e) {
                    try {
                        RestService.this.onSuccess(code, new JSONArray(response));
                    } catch (JSONException e1) {
                        RestService.this.onError(code, "Parsing data bermasalah");
                    }
                }
            }
        }, error -> {
            if (error == null) {
                return;
            }

            if(error.networkResponse == null) {
                onError(code, error.getMessage());
                return;
            }

            String body = "";
            try {
                body = new String(error.networkResponse.data,"UTF-8");
                Log.i("VOLLEY", body);
                RestService.this.onError(code, new JSONObject(body));
            } catch (UnsupportedEncodingException e) {
                onError(code, "Parsing data bermasalah. " + e.getMessage());
            } catch (JSONException e) {
                onError(code, "Parsing data bermasalah. " + e.getMessage());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                statusCode = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };

        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(stringRequest);;
    }

    public void doPost(final int code, String path, final HashMap<String, String> params) {
        if(isShowLoading) {
            loadingDialog.show();
        }

        if(DataHelper.Boolean(context, "IS_LOGIN")) {
            params.put("user_id", DataHelper.String(context, "USER_ID"));
        }

        String url = getBaseURL() + path;
        Log.i("VOLLEY", "URL : " + url);
        Log.i("VOLLEY", "PARAM : " + params);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, response -> {
            Log.i("VOLLEY", response);
            try {
                RestService.this.onSuccess(code, new JSONObject(response));
            } catch (JSONException e) {
                RestService.this.onError(code, "Parsing data bermasalah");
            }
        }, error -> {
            Log.i("VOLLEY", error.toString());
            if (error == null) {
                return;
            }

            if(error.networkResponse == null) {
                onError(code, error.getMessage());
                return;
            }

            String body = "";
            try {
                body = new String(error.networkResponse.data,"UTF-8");
                Log.i("VOLLEY", body);
                RestService.this.onError(code, new JSONObject(body));
            } catch (UnsupportedEncodingException e) {
                onError(code, "Parsing data bermasalah. " + e.getMessage());
            } catch (JSONException e) {
                onError(code, "Parsing data bermasalah. " + e.getMessage());
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Log.i("VOLLEY", params.toString());
                return params;
            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                statusCode = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(stringRequest);
    }

    public void doPostWithJson(final int code, String path, JSONObject params) {
        if(isShowLoading) {
            loadingDialog.show();
        }

        String url = getBaseURL() + path;
        Log.i("VOLLEY", "URL : " + url);
        Log.i("VOLLEY", "PARAM : " + params);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(url, params,
                response -> {
                    Log.i("VOLLEY", response.toString());
                    RestService.this.onSuccess(code, response);
                }, error -> {
                    Log.i("VOLLEY", error.toString());
                    if (error == null) {
                        return;
                    }

                    if(error.networkResponse == null) {
                        onError(code, error.getMessage());
                        return;
                    }
                    String body = "";
                    try {
                        body = new String(error.networkResponse.data,"UTF-8");
                        Log.i("VOLLEY", body);
                        RestService.this.onError(code, new JSONObject(body));
                    } catch (UnsupportedEncodingException e) {
                        onError(code, "Parsing data bermasalah. " + e.getMessage());
                    } catch (JSONException e) {
                        onError(code, "Parsing data bermasalah. " + e.getMessage());
                    }
                }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                if(DataHelper.Boolean(context, "IS_LOGIN")) {
                    Map<String, String>  params = new HashMap<String, String>();
                    params.put("Authorization", "Bearer " + DataHelper.String(context, "ACCESS_TOKEN"));
                    Log.i("VOLLEY", params.toString());
                    return params;
                }
                return super.getHeaders();
            }

            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                statusCode = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };
        jsonObjectRequest.setShouldCache(false);
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(jsonObjectRequest);
    }

    public void doPostWithFiles(int code, String path, HashMap<String, String> params, HashMap<String, byte[]> files) {
        if(isShowLoading) {
            loadingDialog.show();
        }

        if(DataHelper.Boolean(context, "IS_LOGIN")) {
            params.put("user_id", DataHelper.String(context, "USER_ID"));
        }

        String url = getBaseURL() + path;
        Log.i("VOLLEY", url);
        Log.i("VOLLEY", params.toString());
        VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST, url,
                response -> {
                    Log.i("VOLLEY", new String(response.data));
                    try {
                        onSuccess(code, new JSONObject(new String(response.data)));
                    } catch (JSONException e) {
                        onError(code, "Parsing data bermasalah. " + e.getMessage());
                    }
                },
                error -> {
                    if (error == null) {
                        return;
                    }

                    if(error.networkResponse == null) {
                        onError(code, error.getMessage());
                        return;
                    }
                    try {
                        String body = new String(error.networkResponse.data,"UTF-8");
                        Log.i("VOLLEY", body);
                        RestService.this.onError(code, new JSONObject(body));
                    } catch (UnsupportedEncodingException e) {
                        onError(code, "Parsing data bermasalah. " + e.getMessage());
                    } catch (JSONException e) {
                        onError(code, "Parsing data bermasalah. " + e.getMessage());
                    }
                }) {

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {
                Map<String, DataPart> params = new HashMap<>();
                for(String file : files.keySet()) {
                    params.put(file, new DataPart(file, files.get(file)));
                }
                Log.i("VOLLEY", files.keySet().toString());

                return params;
            }
        };

        volleyMultipartRequest.setShouldCache(false);
        volleyMultipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                30*1000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(volleyMultipartRequest);
    }

    public void onError(int code, String response) {
        ResultObject resultObject = new ResultObject();
        resultObject.setCode(statusCode);
        resultObject.setStatus(false);
        resultObject.setMessage(response);
        ViewHelper.showSnackbarWarning(context, "Terjadi kesalahan : " + response, null);

        onDone(code, resultObject);
    }

    public void onError(int code, JSONObject response) {
        ResultObject resultObject = new ResultObject();
        resultObject.setCode(statusCode);
        resultObject.setStatus(false);
        if(response.has("error")) {
            try {
                resultObject.setMessage(response.getString("error"));
                if(isShowError) {
                    ViewHelper.showSnackbarWarning(context, "Terjadi kesalahan : " + response.getString("error"), null);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else if(response.has("error_description")) {
            try {
                resultObject.setMessage(response.getString("error_description"));
                if(isShowError) {
                    ViewHelper.showSnackbarWarning(context, "Terjadi kesalahan : " + response.getString("error_description"), null);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            resultObject.setMessage("Terjadi kesalahan");
            ViewHelper.showSnackbarWarning(context, "Terjadi kesalahan", null);
        }

        onDone(code, resultObject);
    }

    public void onSuccess(int code, JSONArray response) {
        ResultObject resultObject = new ResultObject();
        resultObject.setCode(statusCode);
        resultObject.setStatus(true);
        resultObject.setValue(response);
        onDone(code, resultObject);
    }

    public void onSuccess(int code, JSONObject response) {
        ResultObject resultObject = new ResultObject();
        resultObject.setCode(statusCode);
        try {
            if(response.has("status")) {
                if(response.getBoolean("status")) {
                    resultObject.setStatus(true);
                    if(response.has("value")) {
                        resultObject.setValue(response.get("value"));
                    } else {
                        resultObject.setValue(response);
                    }
                }else {
                    resultObject.setStatus(false);
                    resultObject.setMessage(response.getString("error"));
                    if(isShowError) {
                        ViewHelper.showSnackbarWarning(context, response.getString("error"), null);
                    }
                }
            } else {
                resultObject.setStatus(true);
                if(response.has("value")) {
                    resultObject.setValue(response.get("value"));
                } else {
                    resultObject.setValue(response);
                }
            }

        } catch (JSONException e) {
            resultObject.setStatus(false);
            resultObject.setMessage("Terjadi kesalahan parsing data. " + e.getMessage());
            ViewHelper.showSnackbarWarning(context, "Terjadi kesalahan parsing data. " + e.getMessage(), null);
        }

        onDone(code, resultObject);
    }

    public void onDone(int code, ResultObject resultObject) {
        if(isShowLoading && loadingDialog.isShowing()) {
            loadingDialog.dismiss();
        }
    }

    public void hideLoading() {
        isShowLoading = false;
    }

    public void setShowError() {
        isShowError = true;
    }

    public void hideError() {
        isShowError = false;
    }
}

