package com.modbussid.terbaru.models;

import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Category {
    private int id;
    private String name;

    public Category() {
    }

    public Category(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public static Category fromJSON(JSONObject jsonObject) {
        return new GsonBuilder().create().fromJson(jsonObject.toString(), Category.class);
    }
    public static List<Category> fromJSON(JSONArray jsonArray) throws JSONException {
        List<Category> result = new ArrayList<>();
        for(int i = 0; i < jsonArray.length(); i++) {
            result.add(fromJSON(jsonArray.getJSONObject(i)));
        }

        return result;
    }
}
