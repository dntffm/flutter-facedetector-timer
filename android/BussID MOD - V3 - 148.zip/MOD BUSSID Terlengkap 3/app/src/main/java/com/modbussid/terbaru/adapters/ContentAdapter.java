
package com.modbussid.terbaru.adapters;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.modbussid.terbaru.R;
import com.modbussid.terbaru.UnityConstant;
import com.modbussid.terbaru.models.Content;
import com.modbussid.terbaru.models.Post;
import com.unity3d.services.banners.BannerErrorInfo;
import com.unity3d.services.banners.BannerView;
import com.unity3d.services.banners.UnityBannerSize;

import java.util.ArrayList;
import java.util.List;

public class ContentAdapter extends RecyclerView.Adapter<ContentAdapter.ViewHolder> {
    public List<Content> data = new ArrayList<>();
    public boolean isLoading = false;
    private IAdaperListener<Post> adapterListener;
    public Context context;
    private boolean isEnableAds = true;
    public boolean isLoadFull = false;
    String unityGameID = UnityConstant.GAME_ID;
    Boolean testMode = true;
    String bannerAdId = UnityConstant.BANNER_ADS_ID;

    public ContentAdapter(IAdaperListener<Post> adapterListener) {
        this.adapterListener = adapterListener;
    }

    @Override
    public int getItemViewType(int position) {
        if (isLoading && position == data.size()) {
            return -1;
        }
        if (data.isEmpty()) {
            return 0;
        }

        return data.get(position).getType() == 0 ? 1 : 2;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case -1:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.view_loading_content, parent, false);
                return new ViewHolder(view);
            case 0:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.view_empty, parent, false);
                return new ViewHolder(view);
            case 2:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_ads_native, parent, false);
                return new AddViewHolder((LinearLayout) view);
            default:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_content, parent, false);
                return new ViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (holder.getItemViewType() < 1) {
            return;
        }

        if (holder.getItemViewType() == 2) {
            AddViewHolder addViewHolder = (AddViewHolder) holder;

            // Listener for banner events:
             BannerView.IListener bannerListener = new BannerView.IListener() {
                @Override
                public void onBannerLoaded(BannerView bannerAdView) {
                    // Called when the banner is loaded.
                    Log.v("UnityAdsExample", "onBannerLoaded: " + bannerAdView.getPlacementId());
                }

                @Override
                public void onBannerFailedToLoad(BannerView bannerAdView, BannerErrorInfo errorInfo) {
                    Log.e("UnityAdsExample", "Unity Ads failed to load banner for " + bannerAdView.getPlacementId() + " with error: [" + errorInfo.errorCode + "] " + errorInfo.errorMessage);
                    // Note that the BannerErrorInfo object can indicate a no fill (refer to the API documentation).
                }

                @Override
                public void onBannerClick(BannerView bannerAdView) {
                    // Called when a banner is clicked.
                    Log.v("UnityAdsExample", "onBannerClick: " + bannerAdView.getPlacementId());
                }

                @Override
                public void onBannerLeftApplication(BannerView bannerAdView) {
                    // Called when the banner links out of the application.
                    Log.v("UnityAdsExample", "onBannerLeftApplication: " + bannerAdView.getPlacementId());
                }
            };
            BannerView banner = new BannerView((Activity) context, bannerAdId, new UnityBannerSize(320, 50));
            banner.setListener(bannerListener);
            banner.load();
            addViewHolder.mView.removeAllViews();
            addViewHolder.mView.addView(banner);
        } else {
            holder.loadData(data.get(position));
            holder.vwContent1.setOnClickListener(view -> {
                adapterListener.onSelect(1, data.get(position).getPost1());
            });
        }
    }

    @Override
    public int getItemCount() {
        return isLoading ? data.size() + 1 : data.isEmpty() ? 1 : data.size();
    }

    public void addData(List<Post> posts) {
        isLoadFull = posts.size() % 6 == 0;

        int startIndex = data.size() - 1;
        int numData = 0;
        for (Post post : posts) {
            data.add(new Content(Content.POST_TYPE, post, null));
        }

        if (isEnableAds && posts.size() >= 6) {
            data.add(new Content(Content.ADS_TYPE, null, null));
            numData++;
        }


        notifyItemRangeChanged(startIndex, numData);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public View vwContent1 = null;
        public TextView tvTitle = null, tvDate = null, tvDownloadCount = null, tvRate = null, tvStatus = null;
        public ImageView ivImage = null, ivProBadge = null, ivStatus = null;

        public Content mItem;

        public void loadData(Content mItem) {
            this.mItem = mItem;

            tvTitle.setText(mItem.getPost1().getTitle());
            tvDate.setText(mItem.getPost1().getDate().substring(0, 10));
            tvRate.setText(String.format("%,.1f (%,.0f)", mItem.getPost1().getRate(), mItem.getPost1().getRate_count()));
            loadImage(ivImage, mItem.getPost1().getImage());
            if (mItem.getPost1().getIs_pro() == 1) {
                tvStatus.setText("VIP");
                ivProBadge.setVisibility(View.VISIBLE);
                ivStatus.setImageResource(R.drawable.vip);
            } else {
                tvStatus.setText("FREE");
                ivProBadge.setVisibility(View.GONE);
                ivStatus.setImageResource(R.drawable.free);
            }

            if (mItem.getPost1().getDownload_count() < 1000000) {
                tvDownloadCount.setText(String.format("%,.0f", mItem.getPost1().getDownload_count()));
            } else {
                double count = mItem.getPost1().getDownload_count() / 1000000;
                tvDownloadCount.setText(String.format("%,.0f", count) + "jt");
            }

            if (mItem.getPost1().getRate_count() < 1000000) {
                tvRate.setText(String.format("%,.1f (%,.0f)", mItem.getPost1().getRate(), mItem.getPost1().getRate_count()));
            } else {
                double count = mItem.getPost1().getRate_count() / 1000000;
                tvRate.setText(String.format("%,.1f (%,.0f)", mItem.getPost1().getRate(), count) + "jt");
            }

        }

        public void loadImage(ImageView imageView, String image) {
            Glide.with(context)
                    .load(image)
                    .error(R.drawable.logo)
                    .thumbnail(0.1f)
                    .into(imageView);
        }

        public ViewHolder(View view) {
            super(view);
            mView = view;

            try {
                vwContent1 = mView.findViewById(R.id.vwContent1);
                ivImage = mView.findViewById(R.id.ivImage);
                ivProBadge = mView.findViewById(R.id.ivProBadge);
                tvTitle = mView.findViewById(R.id.tvTitle);
                tvDate = mView.findViewById(R.id.tvDate);
                tvDownloadCount = mView.findViewById(R.id.tvDownloadCount);
                tvRate = mView.findViewById(R.id.tvRate);
                tvStatus = mView.findViewById(R.id.tv_status);
                ivStatus = mView.findViewById(R.id.img_status);
            } catch (Exception ex) {
            }
        }
    }

    public class AddViewHolder extends ViewHolder {
        public final LinearLayout mView;

        public AddViewHolder(@NonNull LinearLayout view) {
            super(view);
            mView = view;
//            itemView.setVisibility(View.GONE);
//            itemView.setLayoutParams(new RecyclerView.LayoutParams(0, 0));
        }
    }


    public boolean isEnableAds() {
        return isEnableAds;
    }

    public void setEnableAds(boolean isEnableAds) {
        this.isEnableAds = isEnableAds;
        List<Content> results = new ArrayList<>();
        for (Content content : data) {
            if (content.getType() == Content.ADS_TYPE) {
                continue;
            }
            results.add(content);
        }

        this.data = results;
        notifyDataSetChanged();
    }

    public void destroyAds() {
    }

    public void clearData() {
        int dataSize = data.size();
        data.clear();
        notifyItemRangeRemoved(0, dataSize);
    }

}
