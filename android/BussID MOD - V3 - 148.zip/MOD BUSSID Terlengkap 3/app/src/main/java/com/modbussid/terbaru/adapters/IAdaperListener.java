package com.modbussid.terbaru.adapters;

public interface IAdaperListener<T> {
    void onSelect(int mode, T data);
}
