package com.modbussid.terbaru.fragments;

import androidx.fragment.app.Fragment;

public class BaseFragment extends Fragment {
    public void LoadData() {
    }
}
