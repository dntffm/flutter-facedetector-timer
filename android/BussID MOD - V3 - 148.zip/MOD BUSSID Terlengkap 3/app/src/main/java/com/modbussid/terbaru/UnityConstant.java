package com.modbussid.terbaru;

public class UnityConstant {
    public static String GAME_ID = "5659750";
    public static String BANNER_ADS_ID = "Banner_Android";
    public static String INTERSTITIAL_ADS_ID = "Interstitial_Android";
    public static String REWARD_ADS_ID = "Rewarded_Android";
}
