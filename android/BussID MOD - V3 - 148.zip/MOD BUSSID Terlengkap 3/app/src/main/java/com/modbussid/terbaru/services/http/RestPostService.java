package com.modbussid.terbaru.services.http;

import android.content.Context;

import java.util.HashMap;

public class RestPostService extends RestService {
    IRestService iRestService;

    public RestPostService(Context context, IRestService iRestService) {
        super(context);
        this.iRestService = iRestService;
    }

    public void Categories(int code) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        this.doGet( code, "data/categories", params);
    }

    public void Banners(int code) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        this.doGet( code, "data/banners", params);
    }

    public void Review(int code, int postID, String userEmail, String userName, float rate) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        params.put("post_id", String.valueOf(postID));
        params.put("user_email",userEmail);
        params.put("user_name",userName);
        params.put("rate",String.valueOf(rate));
        this.doPost( code, "data/postreview", params);
    }

    public void Download(int code, int postID, String userEmail, String userName) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        params.put("post_id", String.valueOf(postID));
        params.put("user_email",userEmail);
        params.put("user_name",userName);
        this.doPost( code, "data/postdownload", params);
    }

    public void Posts(int code, int page, int perPage, String sortBy, String sortType, String category, int isPro, String userEmail, String search) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        params.put("page", String.valueOf(page));
        params.put("per_page", String.valueOf(perPage));
        if(!sortBy.equals("")) {
            params.put("sort_by", sortBy);
        }
        if(!sortType.equals("")) {
            params.put("sort_type", sortType);
        }
        if(!category.equals("")) {
            params.put("category", category);
        }
        if(!userEmail.equals("")) {
            params.put("user_email", userEmail);
        }
        if(!search.equals("")) {
            params.put("search", search);
        }
            params.put("is_pro", String.valueOf(isPro));
        this.doGet( code, "data/posts", params);
    }

    public void Tutorials(int code, int page, int perPage) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        params.put("page", String.valueOf(page));
        params.put("per_page", String.valueOf(perPage));
        this.doGet( code, "data/tutorials", params);
    }

    public void PostDetail(int code, int id, String userEmail) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        params.put("id", String.valueOf(id));
        if(!userEmail.equals("")) {
            params.put("user_email", userEmail);
        }
        this.doGet( code, "data/postdetail", params);
    }

    public void Purchase(int code, String userEmail, String userName, String json) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        params.put("user_email",userEmail);
        params.put("user_name",userName);
        params.put("json",json);
        this.doPost( code, "data/purchase", params);
    }

    public void UserStatus(int code, String userEmail) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        params.put("user_email",userEmail);
        this.doGet( code, "data/userstatus", params);
    }

    public void AdSetting(int code) {
        iRestService.onStart(code);
        HashMap<String, String> params = new HashMap();
        this.doGet(code, "data/ads", params);
    }

    @Override
    public void onDone(int code, ResultObject resultObject) {
        super.onDone(code, resultObject);
        iRestService.onFinish(code, resultObject);
    }
}
