package com.modbussid.terbaru.activities;

import android.os.Bundle;
import android.webkit.WebView;

import com.modbussid.terbaru.R;

public class WebContentActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_content);
        setupToollbar();

        setPageTitle(getIntent().getStringExtra("TITLE"));
        WebView webView = findViewById(R.id.webView);
        webView.loadData(getIntent().getStringExtra("CONTENT"), "text/html", "UTF-8");
    }
}