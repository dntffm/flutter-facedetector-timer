package com.modbussid.terbaru.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.modbussid.terbaru.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.messaging.FirebaseMessaging;
import com.modbussid.terbaru.fragments.AccountFragment;
import com.modbussid.terbaru.fragments.BaseFragment;
import com.modbussid.terbaru.fragments.ContentFragment;
import com.modbussid.terbaru.fragments.TutorialFragment;

public class MainActivity extends AppCompatActivity {
    BaseFragment activeFragment;
    BottomNavigationView btmMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        activeFragment = new ContentFragment();
        changeContent(activeFragment);

        btmMenu = findViewById(R.id.bottomNavigationView);
        btmMenu.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if(item.getItemId() == R.id.nav_account) {
                    activeFragment = new AccountFragment();
                    changeContent(activeFragment);
                    return true;
                } else if(item.getItemId() == R.id.nav_home) {
                    activeFragment = new ContentFragment();
                    changeContent(activeFragment);
                    return true;
                } else if(item.getItemId() == R.id.nav_pro) {
                    activeFragment = new ContentFragment(1);
                    changeContent(activeFragment);
                    return true;
                } else if(item.getItemId() == R.id.nav_tutorial) {
                    activeFragment = new TutorialFragment();
                    changeContent(activeFragment);
                    return true;
                }

                return false;
            }
        });

        if(getIntent().getExtras() != null){
            String isGoToAccount = getIntent().getExtras().getString("go");
            if (isGoToAccount != null && isGoToAccount.equals("account")) {
                gotoAccount();
            }
        }

        FirebaseMessaging.getInstance().subscribeToTopic("general")
            .addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    String msg = "Subscribed";
                    if (!task.isSuccessful()) {
                        msg = "Subscribe failed";
                    }
                    Log.d("FIREBASE", msg);
                }
            });

        askNotificationPermission();
        FirebaseMessaging.getInstance().getToken()
            .addOnCompleteListener(new OnCompleteListener<String>() {
                @Override
                public void onComplete(@NonNull Task<String> task) {
                    if (!task.isSuccessful()) {
                        Log.w("Token", "Fetching FCM registration token failed", task.getException());
                        return;
                    }

                    // Get new FCM registration token
                    String token = task.getResult();
                    Log.d("TOKEN", token);
                }
            });
    }

    // Declare the launcher at the top of your Activity/Fragment:
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    // FCM SDK (and your app) can post notifications.
                } else {
                    // TODO: Inform user that that your app will not show notifications.
                }
            });


    private void askNotificationPermission() {
        // This is only necessary for API level >= 33 (TIRAMISU)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                    PackageManager.PERMISSION_GRANTED) {
                // FCM SDK (and your app) can post notifications.
            } else if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                // TODO: display an educational UI explaining to the user the features that will be enabled
                //       by them granting the POST_NOTIFICATION permission. This UI should provide the user
                //       "OK" and "No thanks" buttons. If the user selects "OK," directly request the permission.
                //       If the user selects "No thanks," allow the user to continue without notifications.
            } else {
                // Directly ask for the permission
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            }
        }
    }

    private void changeContent(Fragment fragment) {
        FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        if(fragment != null) {
            transaction.replace(R.id.content, fragment);
            transaction.commit();
        }
    }

    public void gotoAccount() {
        btmMenu.setSelectedItemId(R.id.nav_account);
    }
}