package com.modbussid.terbaru.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.modbussid.terbaru.R;
import com.modbussid.terbaru.models.Menu;

import java.util.ArrayList;
import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.ViewHolder> {
    public List<Menu> data = new ArrayList<>();
    private IAdaperListener<Menu> adapterListener;
    Context context;

    public MenuAdapter(IAdaperListener<Menu> adapterListener) {
        this.adapterListener = adapterListener;
    }

    @Override
    public int getItemViewType(int position) {
        if (data.get(position).getImage() == 0) {
            return 2;
        } else {
            return 1;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if(viewType == 1) {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_menu, parent, false);
        } else {
            view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_menu_header, parent, false);
        }
        context = view.getContext();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.mView.setOnClickListener(view -> {
            adapterListener.onSelect(1, data.get(position));
        });
        holder.loadData(data.get(position));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public TextView tvTitle;
        public Menu mItem;

        public void loadData(Menu mItem) {
            this.mItem = mItem;
            tvTitle.setText(mItem.getTitle());

            if(mItem.getTitle().equals("Logout")){
                tvTitle.setTextColor(context.getResources().getColor(R.color.main_color));
            } else {
                tvTitle.setTextColor(context.getResources().getColor(com.google.android.ads.nativetemplates.R.color.gnt_gray));
            }
        }

        public ViewHolder(View view) {
            super(view);
            mView = view;
            tvTitle = view.findViewById(R.id.tvTitle);
        }
    }
}
