
package com.modbussid.terbaru.adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.modbussid.terbaru.R;
import com.modbussid.terbaru.models.Post;

import java.util.ArrayList;
import java.util.List;

public class TutorialAdapter extends RecyclerView.Adapter<TutorialAdapter.ViewHolder> {
    public List<Post> data = new ArrayList<>();
    public boolean isLoading = false;
    private IAdaperListener<Post> adapterListener;
    Context context;

    public TutorialAdapter(IAdaperListener<Post> adapterListener) {
        this.adapterListener = adapterListener;
    }

    @Override
    public int getItemViewType(int position) {
        if (isLoading && position == data.size()) {
            return -1;
        }
        if (data.isEmpty()) {
            return 0;
        }

        return 1;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case -1:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.view_loading_content, parent, false);
                context = view.getContext();
                return new ViewHolder(view);
            default:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_tutorial, parent, false);
                context = view.getContext();
                return new ViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (holder.getItemViewType() < 1) {
            return;
        }

        holder.loadData(data.get(position));
        holder.mView.setOnClickListener(view -> {
            adapterListener.onSelect(1, data.get(position));
        });
    }

    @Override
    public int getItemCount() {
        return isLoading ? data.size() + 1 : data.isEmpty() ? 1 : data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public TextView tvTitle = null, tvDate = null;
        public ImageView ivImage = null;
        public Post mItem;

        public void loadData(Post mItem) {
            this.mItem = mItem;

            tvTitle.setText(mItem.getTitle());
            tvDate.setText(mItem.getDate().substring(0, 10));
            Glide.with(context)
                .load(mItem.getImage())
                .addListener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, @Nullable Object model, @NonNull Target<Drawable> target, boolean isFirstResource) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            ivImage.setImageResource(R.drawable.logo);
                        });
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(@NonNull Drawable resource, @NonNull Object model, Target<Drawable> target, @NonNull DataSource dataSource, boolean isFirstResource) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            ivImage.setImageDrawable(resource);
                        });
                        return false;
                    }
                }).submit();
        }

        public ViewHolder(View view) {
            super(view);
            mView = view;

            try {
                ivImage = mView.findViewById(R.id.ivImage);
                tvTitle = mView.findViewById(R.id.tvTitle);
                tvDate = mView.findViewById(R.id.tvDate);
            } catch (Exception ex) {
            }
        }
    }
}
