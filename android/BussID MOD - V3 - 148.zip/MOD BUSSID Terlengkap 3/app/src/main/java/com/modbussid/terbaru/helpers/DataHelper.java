package com.modbussid.terbaru.helpers;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.util.Base64;

import java.io.ByteArrayOutputStream;

public class DataHelper {
    public static final String SP_CONFIG = "BUSSIDMOD";

    static SharedPreferences settings;
    static SharedPreferences.Editor editor;

    public static void Clear(Context act){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        editor = settings.edit();
        editor.clear();
        editor.commit();
    }

    public static void Set(Context act, String key, String value){
        if(act == null){
            return;
        }
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        editor = settings.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public static String String(Context act, String key){
        if(act == null){
            return "";
        }
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        String val = settings.getString(key, "");
        return val;
    }

    public static void Set(Context act, String key, boolean value){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        editor = settings.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public static boolean Boolean(Context act, String key){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        boolean val = settings.getBoolean(key, false);
        return val;
    }

    public static void Set(Context act, String key, Long value){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        editor = settings.edit();
        editor.putLong(key, value);
        editor.commit();
    }

    public static Long Long(Context act, String key){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        Long val = settings.getLong(key, 0);
        return val;
    }

    public static void Set(Context act, String key, Float value){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        editor = settings.edit();
        editor.putFloat(key, value);
        editor.commit();
    }

    public static Float Float(Context act, String key){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        Float val = settings.getFloat(key, 0);
        return val;
    }

    public static void Set(Context act, String key, Integer value){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        editor = settings.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public static Integer Int(Context act, String key){
        settings = act.getSharedPreferences(SP_CONFIG, 0);
        Integer val = settings.getInt(key, 0);
        return val;
    }

    public static String GetBase64(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        byte[] byteArray = byteArrayOutputStream .toByteArray();
        String encoded = Base64.encodeToString(byteArray, Base64.DEFAULT);
        return encoded;
    }

}
