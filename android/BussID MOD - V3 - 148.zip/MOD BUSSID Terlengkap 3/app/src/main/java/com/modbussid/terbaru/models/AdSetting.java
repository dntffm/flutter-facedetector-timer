package com.modbussid.terbaru.models;

import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AdSetting {
    private int id;
    private int inter_ads_click;

    public int getId() {
        return id;
    }

    public static AdSetting fromJSON(JSONObject jsonObject) {
        return new GsonBuilder().create().fromJson(jsonObject.toString(), AdSetting.class);
    }
    public static List<AdSetting> fromJSON(JSONArray jsonArray) throws JSONException {
        List<AdSetting> result = new ArrayList<>();
        for(int i = 0; i < jsonArray.length(); i++) {
            result.add(fromJSON(jsonArray.getJSONObject(i)));
        }

        return result;
    }

    public int getInter_ads_click() {
        return inter_ads_click;
    }

    public void setInter_ads_click(int inter_ads_click) {
        this.inter_ads_click = inter_ads_click;
    }

    public void setId(int id) {
        this.id = id;
    }
}
