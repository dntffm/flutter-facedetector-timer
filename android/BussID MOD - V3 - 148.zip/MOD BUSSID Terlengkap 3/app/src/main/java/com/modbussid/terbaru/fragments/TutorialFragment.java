package com.modbussid.terbaru.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.modbussid.terbaru.R;
import com.modbussid.terbaru.activities.WebContentActivity;
import com.modbussid.terbaru.adapters.TutorialAdapter;
import com.modbussid.terbaru.models.Post;
import com.modbussid.terbaru.services.http.IRestService;
import com.modbussid.terbaru.services.http.RestPostService;
import com.modbussid.terbaru.services.http.ResultObject;

import org.json.JSONArray;
import org.json.JSONException;

public class TutorialFragment extends BaseFragment {
    RestPostService restPostService;
    int page = 1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tutorial, null);

        TutorialAdapter tutorialAdapter = new TutorialAdapter((mode, data) -> {
            Intent intent = new Intent(getContext(), WebContentActivity.class);
            intent.putExtra("TITLE", data.getTitle());
            intent.putExtra("CONTENT", data.getContent());
            startActivity(intent);
        });

        RecyclerView rvLatest = view.findViewById(R.id.rvLatest);
        rvLatest.setLayoutManager(new LinearLayoutManager(getContext()));
        rvLatest.setAdapter(tutorialAdapter);
        NestedScrollView nestedScrollView = view.findViewById(R.id.nestedScrollView);
        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener()
        {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY)
            {
                if (v.getChildAt(v.getChildCount() - 1) != null)
                {
                    if (scrollY > oldScrollY)
                    {
                        if (scrollY >= (v.getChildAt(v.getChildCount() - 1).getMeasuredHeight() - v.getMeasuredHeight()))
                        {
                            //code to fetch more data for endless scrolling
                            page++;
                            restPostService.Posts(2, page,10,"download_count","desc", "", -1,"", "");
                        }
                    }
                }
            }
        });

        restPostService = new RestPostService(getContext(), new IRestService() {
            @Override
            public void onStart(int code) {
                if(code == 1) {
                    tutorialAdapter.isLoading = true;
                    tutorialAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFinish(int code, ResultObject value) {
                if(value.isStatus()) {
                    if (code == 1) {
                        try {
                            tutorialAdapter.isLoading = false;
                            tutorialAdapter.data.addAll(Post.fromJSON((JSONArray) value.getValue()));
                            tutorialAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });


        restPostService.Tutorials(1, page,10);
        return view;
    }
}
