package com.modbussid.terbaru.fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.modbussid.terbaru.R;
import com.modbussid.terbaru.UnityConstant;
import com.modbussid.terbaru.WrapContentLinearLayoutManager;
import com.modbussid.terbaru.activities.MainActivity;
import com.modbussid.terbaru.activities.PostDetailActivity;
import com.modbussid.terbaru.adapters.BannerAdapter;
import com.modbussid.terbaru.adapters.CategoryAdapter;
import com.modbussid.terbaru.adapters.ContentAdapter;
import com.modbussid.terbaru.helpers.DataHelper;
import com.modbussid.terbaru.models.AdSetting;
import com.modbussid.terbaru.models.Banner;
import com.modbussid.terbaru.models.Category;
import com.modbussid.terbaru.models.Post;
import com.modbussid.terbaru.services.http.IRestService;
import com.modbussid.terbaru.services.http.RestPostService;
import com.modbussid.terbaru.services.http.ResultObject;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ContentFragment extends BaseFragment {
    RestPostService restPostService;
    int page = 1;
    String categoryID = "";
    int isPro = 0;

    String sortBy = "date";
    Post selectedPost = null;

    int spinnerSelectedCount = 0;

    List<Integer> categoryIds;

    Spinner spinnerCategory;

    ArrayAdapter<String> categoryAdapter;

    List<String> categoryNames;
    int interClickInterval = 3;


    public ContentFragment() {
    }


    public ContentFragment(int isPro) {
        this.isPro = isPro;
    }

    ContentAdapter contentLatestAdapter;
    SearchView searchView;

    private final String TAG = ContentFragment.class.getSimpleName();

    private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
        @Override
        public void onUnityAdsAdLoaded(String placementId) {
            UnityAds.show(requireActivity(), UnityConstant.INTERSTITIAL_ADS_ID, new UnityAdsShowOptions(), showListener);
        }

        @Override
        public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
            Log.e("UnityAdsExample", "Unity Ads failed to load ad for " + placementId + " with error: [" + error + "] " + message);
        }
    };

    private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
        @Override
        public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
            Log.e("UnityAdsExample", "Unity Ads failed to show ad for " + placementId + " with error: [" + error + "] " + message);
            if (selectedPost != null) {
                Intent intent = new Intent(getContext(), PostDetailActivity.class);
                intent.putExtra("ID", selectedPost.getId());
                intent.putExtra("TITLE", selectedPost.getTitle());
                startActivity(intent);
            }
        }

        @Override
        public void onUnityAdsShowStart(String placementId) {
            Log.v("UnityAdsExample", "onUnityAdsShowStart: " + placementId);
        }

        @Override
        public void onUnityAdsShowClick(String placementId) {
            Log.v("UnityAdsExample", "onUnityAdsShowClick: " + placementId);
        }

        @Override
        public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
            Log.v("UnityAdsExample", "onUnityAdsShowComplete: " + placementId);
            if (selectedPost != null) {
                Intent intent = new Intent(getContext(), PostDetailActivity.class);
                intent.putExtra("ID", selectedPost.getId());
                intent.putExtra("TITLE", selectedPost.getTitle());
                startActivity(intent);
            }
        }
    };


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_content, null);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getContext());
        String email;
        if (account != null) {
            email = account.getEmail();
        } else {
            email = "";
        }

        spinnerCategory = view.findViewById(R.id.spinner_category);
        categoryNames = new ArrayList<>();
        categoryAdapter = new ArrayAdapter<>(requireActivity(), R.layout.spinner_item, categoryNames);
        spinnerCategory.setAdapter(categoryAdapter);
        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

                if(position == 0){
                    categoryID = "";
                } else{
                    categoryID = String.valueOf(categoryIds.get(position - 1));
                }

                page = 1;

                contentLatestAdapter.clearData();
                restPostService.Posts(2, page, 6, sortBy, "desc", categoryID, isPro, email, searchView.getQuery().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        View rvBannerShimmer = view.findViewById(R.id.rvBannerShimmer);
        RecyclerView rvBanner = view.findViewById(R.id.rvBanner);
        rvBanner.setLayoutManager(new WrapContentLinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        BannerAdapter bannerAdapter = new BannerAdapter((mode, data) -> {
        });

        rvBanner.setAdapter(bannerAdapter);
        SnapHelper helper = new LinearSnapHelper();
        helper.attachToRecyclerView(rvBanner);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                LinearLayoutManager llm = (LinearLayoutManager) rvBanner.getLayoutManager();
                if (llm.findLastVisibleItemPosition() + 1 >= bannerAdapter.getItemCount()) {
                    rvBanner.smoothScrollToPosition(0);
                } else {
                    rvBanner.smoothScrollToPosition(llm.findLastVisibleItemPosition() + 1);
                }
                new Handler().postDelayed(this, 5 * 1000);
            }
        }, 5 * 1000);


        DataHelper.Set(getActivity(), "CLICK_POST", 0);

        contentLatestAdapter = new ContentAdapter((mode, data) -> {
            selectedPost = data;
            if (selectedPost != null && data.getIs_can_access() == 1) {
                int numPost = DataHelper.Int(getActivity(), "CLICK_POST");
                numPost++;
                if (contentLatestAdapter.isEnableAds() && numPost >= interClickInterval) {
                    numPost = 0;

                    UnityAds.load(UnityConstant.INTERSTITIAL_ADS_ID, loadListener);
                } else {
                    Intent intent = new Intent(getContext(), PostDetailActivity.class);
                    intent.putExtra("ID", data.getId());
                    intent.putExtra("TITLE", data.getTitle());
                    startActivity(intent);
                }
                DataHelper.Set(getActivity(), "CLICK_POST", numPost);
            } else {

                DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case DialogInterface.BUTTON_POSITIVE:
                                ((MainActivity) getActivity()).gotoAccount();
                                break;

                            case DialogInterface.BUTTON_NEGATIVE:
                                //No button clicked
                                break;
                        }
                    }
                };
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setMessage(getString(R.string.dialog_upgrade_title)).setPositiveButton(getString(R.string.upgrade_account), dialogClickListener).setNegativeButton(getString(R.string.cancel), dialogClickListener).show();
            }
        });
        contentLatestAdapter.context = getActivity();

        RecyclerView rvLatest = view.findViewById(R.id.rvLatest);
        WrapContentLinearLayoutManager linearLayoutManager = new WrapContentLinearLayoutManager(getContext());
        rvLatest.setLayoutManager(linearLayoutManager);
        rvLatest.setAdapter(contentLatestAdapter);

        rvLatest.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                if (!contentLatestAdapter.isLoading && contentLatestAdapter.isLoadFull) {
                    int visibleItemCount = linearLayoutManager.getChildCount();
                    int totalItemCount = linearLayoutManager.getItemCount();
                    int pastItemVisible = linearLayoutManager.findFirstVisibleItemPosition();

                    if ((visibleItemCount + pastItemVisible) == totalItemCount) {
                        page++;
                        restPostService.Posts(2, page, 6, sortBy, "desc", categoryID, isPro, email, searchView.getQuery().toString());
                        Log.d("Scrollmore", "" + page);
                    }
                }
            }
        });

        restPostService = new RestPostService(getContext(), new IRestService() {
            @Override
            public void onStart(int code) {
                if (code == 1) {
                } else if (code == 2) {
                    contentLatestAdapter.isLoading = true;
                    if (contentLatestAdapter.data.size() == 0) {
                        rvLatest.post(() -> contentLatestAdapter.notifyDataSetChanged());
                    } else {
                        rvLatest.post(() -> contentLatestAdapter.notifyItemChanged(contentLatestAdapter.data.size()));
                    }
                } else if (code == 4) {
                    rvBannerShimmer.setVisibility(View.VISIBLE);
                    rvBanner.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFinish(int code, ResultObject value) {
                if (value.isStatus()) {
                    if (code == 1) {
                        try {
                            List<Category> categories = Category.fromJSON((JSONArray) value.getValue());

                            categoryIds = categories.stream()
                                    .map(Category::getId)
                                    .collect(Collectors.toList());

                            categoryNames = categories.stream()
                                    .map(Category::getName)
                                    .collect(Collectors.toList());

                            categoryNames.add(0, "All");

                            categoryAdapter.clear();
                            categoryAdapter.addAll(categoryNames);
                            categoryAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else if (code == 2) {
                        try {
                            contentLatestAdapter.isLoading = false;
                            List<Post> data = Post.fromJSON((JSONArray) value.getValue());
                            contentLatestAdapter.addData(data);
                        } catch (JSONException e) {
                            Log.d("ContentFragmentOnFinish", "onFinish: " + e.getLocalizedMessage());
                            contentLatestAdapter.clearData();
                        }
                    } else if (code == 3) {
                        contentLatestAdapter.setEnableAds(false);
                    } else if (code == 4) {
                        try {
                            rvBannerShimmer.setVisibility(View.GONE);
                            rvBanner.setVisibility(View.VISIBLE);
                            bannerAdapter.data = Banner.fromJSON((JSONArray) value.getValue());
                            bannerAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    } else if(code == 5){
                        AdSetting adSetting = AdSetting.fromJSON((JSONObject) value.getValue());
                        interClickInterval = adSetting.getInter_ads_click();
                    }
                }
            }
        });

        Spinner spinner = view.findViewById(R.id.spinner_filter);
        String[] items = new String[]{"Terbaru", "Terpopuler"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireActivity(), R.layout.spinner_item, items);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if (++spinnerSelectedCount > 1) {
                    contentLatestAdapter.clearData();
                    page = 1;
                    if (position == 0) {
                        sortBy = "date";
                        restPostService.Posts(2, page, 6, sortBy, "desc", categoryID, isPro, email, searchView.getQuery().toString());
                    } else {
                        sortBy = "rate";
                        restPostService.Posts(2, page, 6, sortBy, "desc", categoryID, isPro, email, searchView.getQuery().toString());
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        LoadData();

        restPostService.Categories(1);
        restPostService.Posts(2, page, 6, sortBy, "desc", categoryID, isPro, email, "");
        restPostService.UserStatus(3, email);
        restPostService.Banners(4);
        restPostService.AdSetting(5);

        searchView = view.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                contentLatestAdapter.clearData();
                page = 1;
                restPostService.Posts(2, page, 6, sortBy, "desc", categoryID, isPro, email, query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        searchView.setFocusable(false);
        searchView.setIconified(false);
        searchView.clearFocus();

        return view;
    }


    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void LoadData() {
        super.LoadData();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        contentLatestAdapter.destroyAds();
    }


}
