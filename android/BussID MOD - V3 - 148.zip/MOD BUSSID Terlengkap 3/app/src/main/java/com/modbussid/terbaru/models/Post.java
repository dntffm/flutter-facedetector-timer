package com.modbussid.terbaru.models;

import com.google.gson.GsonBuilder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Post {
    private String title, content;
    private int id, is_pro, is_can_access;
    private double rate, download_count, user_rate, rate_count;
    private String date;
    private String image;
    private String download_codes;

    public Double getUser_rate() {
        return user_rate;
    }

    public double getRate_count() {
        return rate_count;
    }

    public String getTitle() {
        return title;
    }

    public String getImage() {
        return image;
    }

    public String getContent() {
        return content;
    }

    public int getId() {
        return id;
    }

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
    public String getDate() {
        try {
            return sdf1.format(sdf.parse(date));
        } catch (ParseException e) {
            return date;
        }
    }

    public double getRate() {
        return rate;
    }

    public double getDownload_count() {
        return download_count;
    }

    public String getDownload_codes() {
        return download_codes;
    }

    public List<String> getDownloadCode() {
        List<String> results = Arrays.asList(download_codes.split(","));
        return results;
    }

    public List<String> getDownloadCodeOld() {
        List<String> results = new ArrayList<>();

        int startIndex = 0;
        String text = content;
        while (true) {
            startIndex = text.indexOf("https://download.modbussid.co.id/");
            if(startIndex < 0) {
                break;
            }
            int endIndex = startIndex+"https://download.modbussid.co.id/".length() + 3;
            results.add(text.substring(startIndex+"https://download.modbussid.co.id/".length(),endIndex));

            text = text.substring(endIndex, text.length());
        }

        return results;
    }

    public String getContentWithoutDownloadLink() {
        int startIndex = content.indexOf("Link download bermasalah?");
        if(startIndex > -1) {
            return content.substring(startIndex, content.length());
        }

        return content;
    }

    public int getIs_pro() {
        return is_pro;
    }

    public int getIs_can_access() {
        return is_can_access;
    }

    public static Post fromJSON(JSONObject jsonObject) {
        return new GsonBuilder().create().fromJson(jsonObject.toString(), Post.class);
    }
    public static List<Post> fromJSON(JSONArray jsonArray) throws JSONException {
        List<Post> result = new ArrayList<>();
        for(int i = 0; i < jsonArray.length(); i++) {
            result.add(fromJSON(jsonArray.getJSONObject(i)));
        }

        return result;
    }
}
