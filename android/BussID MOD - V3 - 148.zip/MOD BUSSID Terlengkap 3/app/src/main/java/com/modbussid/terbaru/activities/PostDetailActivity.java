package com.modbussid.terbaru.activities;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;
import com.modbussid.terbaru.R;
import com.modbussid.terbaru.UnityConstant;
import com.modbussid.terbaru.dialogs.ReviewDialog;
import com.modbussid.terbaru.helpers.DataHelper;
import com.modbussid.terbaru.helpers.PermissionHelper;
import com.modbussid.terbaru.helpers.ViewHelper;
import com.modbussid.terbaru.models.Post;
import com.modbussid.terbaru.services.http.IRestService;
import com.modbussid.terbaru.services.http.RestPostService;
import com.modbussid.terbaru.services.http.ResultObject;
import com.unity3d.ads.IUnityAdsLoadListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

import org.json.JSONObject;

import java.io.File;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PostDetailActivity extends BaseActivity {

    RestPostService restPostService;
    String downloadCode = "";
    Button btnDownload, btnWa;

    long downloadID = 0;

    ReviewDialog reviewDialog;
    int postID;

    boolean isProUser = false;

    Button btnRate;
    String email = "";

    // Indicate that we would like to update download progress
    private static final int UPDATE_DOWNLOAD_PROGRESS = 1;

    // Use a background thread to check the progress of downloading
    private ExecutorService executor;

    // Use a hander to update progress bar on the main thread
    private Handler mainHandler;

    private final String TAG = PostDetailActivity.class.getSimpleName();

    private IUnityAdsLoadListener loadListener = new IUnityAdsLoadListener() {
        @Override
        public void onUnityAdsAdLoaded(String placementId) {
        }

        @Override
        public void onUnityAdsFailedToLoad(String placementId, UnityAds.UnityAdsLoadError error, String message) {
            Log.e("UnityAdsExample", "Unity Ads failed to load ad for " + placementId + " with error: [" + error + "] " + message);
        }
    };

    private IUnityAdsShowListener showListener = new IUnityAdsShowListener() {
        @Override
        public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {
            Log.e("UnityAdsExample", "Unity Ads failed to show ad for " + placementId + " with error: [" + error + "] " + message);
            download();
        }

        @Override
        public void onUnityAdsShowStart(String placementId) {
            Log.v("UnityAdsExample", "onUnityAdsShowStart: " + placementId);
        }

        @Override
        public void onUnityAdsShowClick(String placementId) {
            Log.v("UnityAdsExample", "onUnityAdsShowClick: " + placementId);
        }

        @Override
        public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
            Log.v("UnityAdsExample", "onUnityAdsShowComplete: " + placementId);
            if (state.equals(UnityAds.UnityAdsShowCompletionState.COMPLETED)) {
                // Reward the user for watching the ad to completion
                download();
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);
        if (isTaskRoot())
            setUpToolbarPostRoot();
        else
            setupToollbar();
        setPageTitle(getIntent().getStringExtra("TITLE"));

        TextView tvTitle = findViewById(R.id.tvTitle);
        TextView tvDate = findViewById(R.id.tvDate);
        ImageView ivImage = findViewById(R.id.ivImage);
        TextView tvContent = findViewById(R.id.tvContent);
        TextView tvRate = findViewById(R.id.tvRate);
        TextView tvDownloadCount = findViewById(R.id.tvDownloadCount);
        Button btnWa = findViewById(R.id.btnWa);

        restPostService = new RestPostService(this, new IRestService() {
            @Override
            public void onStart(int code) {
                if (code == 1) {
                    findViewById(R.id.vwLoading).setVisibility(View.VISIBLE);
                    findViewById(R.id.vwResult).setVisibility(View.GONE);
                }
            }


            @Override
            public void onFinish(int code, ResultObject value) {
                if (value.isStatus()) {
                    if (code == 1) {
                        Post post = Post.fromJSON((JSONObject) value.getValue());

                        List<String> codes = post.getDownloadCode();
                        if (codes.size() > 0) {
                            downloadCode = post.getDownloadCode().get(0);
                        } else {
                            btnDownload.setVisibility(View.GONE);
                        }

                        findViewById(R.id.vwLoading).setVisibility(View.GONE);
                        findViewById(R.id.vwResult).setVisibility(View.VISIBLE);

                        tvTitle.setText(post.getTitle());
                        tvDate.setText(post.getDate().substring(0, 10));
                        tvContent.setText(Html.fromHtml(post.getContentWithoutDownloadLink()));
                        tvContent.setMovementMethod(LinkMovementMethod.getInstance());
                        tvRate.setText(String.format("%,.1f (%,.0f)", post.getRate(), post.getRate_count()));
                        tvDownloadCount.setText(String.format("%,.0f", post.getDownload_count()));

                        if (post.getUser_rate() != null) {
                            reviewDialog.setRate(post.getUser_rate());
                        }

                        Glide.with(getApplicationContext())
                                .load(post.getImage())
                                .error(R.drawable.logo)
                                .into(ivImage);
                    } else if (code == 2) {
                        ViewHelper.showSnackbarWarning(PostDetailActivity.this, getString(R.string.rate_success), null);
                        restPostService.PostDetail(1, postID, email);
                    } else if (code == 3) {
                        isProUser = true;
                    }
                }
            }
        });

        UnityAds.load(UnityConstant.REWARD_ADS_ID, loadListener);

        btnWa.setOnClickListener(view -> {
            if (isProUser) {
                String url = getString(R.string.wa_number);
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            } else {
                DialogInterface.OnClickListener dialogClickListener = (dialog, which) -> {
                    switch (which) {
                        case DialogInterface.BUTTON_POSITIVE:
                            Intent i = new Intent(this, MainActivity.class);
                            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            i.putExtra("go", "account");
                            startActivity(i);
                            break;

                        case DialogInterface.BUTTON_NEGATIVE:
                            dialog.dismiss();
                            break;
                    }
                };
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(getString(R.string.dialog_upgrade_title))
                        .setPositiveButton(getString(R.string.upgrade_account), dialogClickListener)
                        .setNegativeButton(getString(R.string.cancel), dialogClickListener).show();
            }
        });

        postID = getIntent().getIntExtra("ID", 0);
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null) {
            email = account.getEmail();
        }
        restPostService.PostDetail(1, postID, email);

        btnDownload = findViewById(R.id.btnDownload);
        btnDownload.setOnClickListener(view -> {
            Log.d("PostDetailActivity", "onCreate: Start download");
            startDownload();
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            IntentFilter filters = new IntentFilter();
            filters.addAction(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
            filters.addAction(PostDetailActivity.this.getPackageName());

            ContextCompat.registerReceiver(PostDetailActivity.this,
                    onDownloadComplete,
                    filters,
                    ContextCompat.RECEIVER_EXPORTED);
        } else {
            registerReceiver(onDownloadComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
        }

        btnRate = findViewById(R.id.btnRate);
        btnRate.setOnClickListener(view -> {
            if (account == null) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                                .requestEmail()
                                .build();
                        GoogleSignInClient mGoogleSignInClient = GoogleSignIn.getClient(PostDetailActivity.this, gso);
                        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                        startActivityForResult(signInIntent, 1);
                    }
                }, 2000);
            } else {
                reviewDialog.show(getSupportFragmentManager().beginTransaction().remove(reviewDialog), null);
            }
        });

        reviewDialog = new ReviewDialog(new ReviewDialog.ReviewDialogCallback() {
            @Override
            public void onReview(float rate) {
                GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(PostDetailActivity.this);
                restPostService.Review(2, postID, account.getEmail(), account.getDisplayName(), rate);
            }
        });

        restPostService.UserStatus(3, email);
    }

    public void startDownload() {
        if (downloadCode.equals("")) {
            Toast.makeText(this, getString(R.string.cannot_download_file), Toast.LENGTH_LONG).show();
            return;
        }
        if (!btnDownload.getText().equals("Download")) {
            Toast.makeText(this, getString(R.string.download_running), Toast.LENGTH_LONG).show();
            return;
        }

        String[] perms;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            perms = new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE};
        } else {
            perms = new String[]{Manifest.permission.READ_MEDIA_IMAGES};
        }

        if (!PermissionHelper.CheckIfAlreadyhavePermission(this, perms, 101)) {
            return;
        }

        if (!isProUser) {
            final Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.dialog_download_post);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            ImageButton btnClose = dialog.findViewById(R.id.btnClose);
            Button btnPro = dialog.findViewById(R.id.btnPro);
            Button btnFree = dialog.findViewById(R.id.btnFree);

            btnClose.setOnClickListener(v -> dialog.dismiss());
            btnFree.setOnClickListener(v -> {
                dialog.dismiss();
                UnityAds.show(this, UnityConstant.REWARD_ADS_ID, new UnityAdsShowOptions(), showListener);
            });

            btnPro.setOnClickListener(v -> {
                Intent i = new Intent(this, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                i.putExtra("go", "account");
                startActivity(i);
            });

            dialog.show();
        } else {
            Log.d("Isprouser", "false");
            download();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            reviewDialog.show(getSupportFragmentManager().beginTransaction().remove(reviewDialog), null);
        } catch (ApiException e) {
            Log.w("GOOGLE", "signInResult:failed code=" + e.getStatusCode());
            Toast.makeText(this, "Terjadi kesalahan saat login. kode " + e.getStatusCode(), Toast.LENGTH_SHORT).show();
//            updateUI(null);
        }
    }

    private BroadcastReceiver onDownloadComplete = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d("checkdownload", "onReceive: ");
            try {
                //Fetching the download id received with the broadcast
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                //Checking if the received broadcast is for our enqueued download by matching download id
                if (downloadID == id) {
                    btnDownload.setText("Download");
                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which) {
                                case DialogInterface.BUTTON_POSITIVE:
                                    try {
                                        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.maleo.bussimulatorid");
                                        startActivity(launchIntent);
                                    } catch (Exception ex) {
                                        final String appPackageName = "com.maleo.bussimulatorid"; // getPackageName() from Context or Activity object
                                        try {
                                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + appPackageName)));
                                        } catch (android.content.ActivityNotFoundException anfe) {
                                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName)));
                                        }
                                    }
                                    //Yes button clicked
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };
                    File directory;
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                        directory = new File(Environment.getExternalStorageDirectory(), "BUSSID/Mods");
                    } else {
                        directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "BUSSID/Mods");
                    }
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setMessage(getString(R.string.success_download) + directory.getPath())
                            .setPositiveButton(getString(R.string.open_game), dialogClickListener)
                            .setNegativeButton(getString(R.string.close), dialogClickListener)
                            .show();

                    executor.shutdown();
                    mainHandler.removeCallbacksAndMessages(null);

                    boolean isDownloadSuccess = DataHelper.Boolean(PostDetailActivity.this, "DOWNLOAD_POST");
                    if (isDownloadSuccess) {
                        ReviewManager manager = ReviewManagerFactory.create(getApplicationContext());
                        Task<ReviewInfo> request = manager.requestReviewFlow();
                        request.addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                // We can get the ReviewInfo object
                                ReviewInfo reviewInfo = task.getResult();
                                Task<Void> flow = manager.launchReviewFlow(PostDetailActivity.this, reviewInfo);
                                flow.addOnCompleteListener(task1 -> {
                                });
                            } else {
                                // There was some problem, log or handle the error code.
//                                @ReviewErrorCode int reviewErrorCode = ((ReviewException) task.getException()).getErrorCode();
                            }
                        });
                    } else {
                        DataHelper.Set(PostDetailActivity.this, "DOWNLOAD_POST", true);
                    }
                }
            } catch (Exception ex) {
                Log.d("checkdownload", ex.getMessage());
                ex.printStackTrace();
            }
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 101: {
                if (grantResults.length > 0) {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                            return;
                        }
                    }
                    btnDownload.performClick();
                }
            }
        }
    }

    void download() {
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(PostDetailActivity.this);
        if (account != null) {
            restPostService.Download(4, postID, account.getEmail(), account.getDisplayName());
        } else {
            restPostService.Download(4, postID, "", "");
        }

        CookieManager manager = new CookieManager();
        CookieHandler.setDefault(manager);

        btnDownload.setText("Download: Auth ...");
        String url = "https://download.modbussid.co.id/account/login";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, response -> {
        }, error -> {
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", "admin");
                params.put("password", "ananda21");
                params.put("submitme", "1");
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                return super.getHeaders();
            }

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                DownloadFileFromURL downloadFileFromURL = new DownloadFileFromURL();
                downloadFileFromURL.execute("https://download.modbussid.co.id/" + downloadCode);
                return super.parseNetworkResponse(response);
            }
        };
        stringRequest.setShouldCache(false);
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                0,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    class DownloadFileFromURL extends AsyncTask<String, String, String[]> {
        /**
         * Before starting background thread
         * Show Progress Bar Dialog
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        /**
         * Downloading file in background thread
         */
        @Override
        protected String[] doInBackground(String... f_url) {
            try {
                publishProgress("File ...");

                URL url = new URL(f_url[0]);
                URLConnection conection = url.openConnection();
                conection.connect();
                int lengthFile = conection.getContentLength();
                // this will be useful so that you can show a tipical 0-100%           progress bar
                URL finalURL = conection.getURL();
                String raw = conection.getHeaderField("Content-Disposition");
                String fileName = tvPageTitle.getText().toString().replace(" ", "_") + ".bussidmod";
                if (raw != null && raw.indexOf("=") != -1) {
                    fileName = raw.split("=")[1].replaceAll("\"", ""); //getting value after '='
                }

                return new String[]{finalURL.toString(), fileName};

            } catch (Exception e) {
                Log.e("Error: ", e.getMessage());
            }

            return null;
        }

        /**
         * Updating progress bar
         */
        protected void onProgressUpdate(String... progress) {
            // setting progress percentage
            Log.d("PROGRESS", progress[0]);
            btnDownload.setText(String.format("Download: %s", progress[0]));
        }

        /**
         * After completing background task
         * Dismiss the progress dialog
         **/
        @Override
        protected void onPostExecute(String[] file_url) {
            try {
                File directory;
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    directory = new File(Environment.getExternalStorageDirectory(), "BUSSID/Mods");
                } else {
                    directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "BUSSID/Mods");
                }

                if (!directory.exists()) {
                    if (!directory.mkdirs()) {
                        return;
                    }
                }

                // Output stream
                File file = new File(directory.getPath() + File.separator + file_url[1]);

                btnDownload.setText("Download: Running ...");
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(file_url[0]))
                        .setTitle(tvPageTitle.getText().toString())// Title of the Download Notification
                        .setDescription("Downloading ...")// Description of the Download Notification
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)// Visibility of the download Notification
                        .setDestinationUri(Uri.fromFile(file))// Uri of the destination file
                        .setAllowedOverMetered(true)// Set if download is allowed on Mobile network
                        .setAllowedOverRoaming(true);// Set if download is allowed on roaming network
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOCUMENTS, "BUSSID/Mods/" + file.getName());
                }
                DownloadManager downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                downloadID = downloadManager.enqueue(request);// enqueue puts the download request in the queue.
                // Run a task in a background thread to check download progress

                executor = Executors.newFixedThreadPool(1);
                mainHandler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
                    @Override
                    public boolean handleMessage(@NonNull Message msg) {
                        if (msg.what == UPDATE_DOWNLOAD_PROGRESS) {
                            int downloadProgress = msg.arg1;

                            // Update your progress bar here.
                            btnDownload.setText("Download : " + downloadProgress + "%");
                        }
                        return true;
                    }
                });

                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        int progress = 0;
                        boolean isDownloadFinished = false;
                        while (!isDownloadFinished) {
                            try {
                                Cursor cursor = downloadManager.query(new DownloadManager.Query().setFilterById(downloadID));
                                if (cursor != null) {
                                    if (cursor.moveToFirst()) {
                                        int downloadStatus = cursor.getInt(cursor.getColumnIndex(DownloadManager.COLUMN_STATUS));
                                        switch (downloadStatus) {
                                            case DownloadManager.STATUS_RUNNING:
                                                long totalBytes = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                                                if (totalBytes > 0) {
                                                    long downloadedBytes = cursor.getLong(cursor.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                                                    progress = (int) (downloadedBytes * 100 / totalBytes);
                                                }

                                                break;
                                            case DownloadManager.STATUS_SUCCESSFUL:
                                                progress = 100;
                                                isDownloadFinished = true;
                                                break;
                                            case DownloadManager.STATUS_PAUSED:
                                            case DownloadManager.STATUS_PENDING:
                                                break;
                                            case DownloadManager.STATUS_FAILED:
                                                isDownloadFinished = true;
                                                break;
                                        }
                                        Message message = Message.obtain();
                                        message.what = UPDATE_DOWNLOAD_PROGRESS;
                                        message.arg1 = progress;
                                        mainHandler.sendMessage(message);
                                    }
                                    cursor.close();
                                }
                            } catch (Exception ignored) {

                            }
                        }
                    }
                });
            } catch (Exception e) {
                Toast.makeText(PostDetailActivity.this, "Terjadi kesalahan", Toast.LENGTH_SHORT).show();
            }

        }

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (isTaskRoot()) {
            Intent intent = new Intent(this, MainActivity.class);// New activity
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        }
        super.onBackPressed();
    }
}