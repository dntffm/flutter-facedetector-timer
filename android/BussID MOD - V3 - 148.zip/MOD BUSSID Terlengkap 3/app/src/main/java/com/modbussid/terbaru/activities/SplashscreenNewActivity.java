package com.modbussid.terbaru.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.modbussid.terbaru.R;
import com.modbussid.terbaru.UnityConstant;
import com.modbussid.terbaru.services.http.IRestService;
import com.modbussid.terbaru.services.http.RestPostService;
import com.modbussid.terbaru.services.http.ResultObject;
import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.UnityAds;

public class SplashscreenNewActivity extends AppCompatActivity {

    RestPostService restPostService;

    private String unityGameID = UnityConstant.GAME_ID;
    private Boolean testMode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);

        // Initialize the SDK:
        UnityAds.initialize(getApplicationContext(), unityGameID, testMode, new IUnityAdsInitializationListener() {
            @Override
            public void onInitializationComplete() {
                Log.d("unityads", "onInitializationComplete: ");
                init();
            }

            @Override
            public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                Log.d("unityads", "onInitializationFailed: " + message);
                init();
            }
        });
    }

    public void init(){

        restPostService = new RestPostService(this, new IRestService() {
            @Override
            public void onStart(int code) {
            }

            @Override
            public void onFinish(int code, ResultObject value) {
                startMainActivity();
            }
        });


        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        String email;
        if (account != null) {
            email = account.getEmail();
        } else {
            email = "";
        }
        restPostService.UserStatus(1, email);
    }

    /**
     * Start the MainActivity.
     */
    public void startMainActivity() {
        finish();
        String type = getIntent().getStringExtra("type");
        String id = getIntent().getStringExtra("id");
        String title = getIntent().getStringExtra("title");
        if (type == null) {
            Intent intent = new Intent(this, MainActivity.class);
            this.startActivity(intent);
        } else if (type.equals("content")) {
            Intent intent = new Intent(this, PostDetailActivity.class);
            intent.putExtra("ID", Integer.parseInt(id));
            intent.putExtra("TITLE", title);
            this.startActivity(intent);
        }
    }
}
